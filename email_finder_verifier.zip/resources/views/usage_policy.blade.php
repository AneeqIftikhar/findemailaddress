@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><h3>Usage Policy</h3></div>

                <div class="card-body">
                        Find Email consumes 3 credits
                        Verify Email consumes 1 credit
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
