<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><h3>Usage Policy</h3></div>

                <div class="card-body">
                        Find Email consumes 3 credits
                        Verify Email consumes 1 credit
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\email_finder_verifier\resources\views/usage_policy.blade.php ENDPATH**/ ?>