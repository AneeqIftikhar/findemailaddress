<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Lists</div>

                <div class="card-body">
                    <div class="row" style="margin-bottom: 4px">
                        <div class="col-md-10">
                            <h3>Your Files are Listed Here</h3>
                        </div>
                        <!-- <div class="col-md-2">
                            <button class="btn btn-danger">Delete</button>
                        </div> -->
                    </div>
                   <table class="table" id="files_table">
                      <thead class="black white-text">
                        <tr>
                            <th scope="col">Title</th>
                            <th scope="col">Status</th>
                            <th scope="col">Date/Time Uploaded</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr class="table-row" data-href="<?php echo e(URL::route('emails', ['id' => $file->id])); ?>" value="<?php echo e($file->id); ?>">        
                              <td> <?php echo e($file->title); ?> </td>
                              <td> <?php echo e($file->status); ?> </td>
                              <td> <?php echo e($file->created_at); ?> </td>
                          </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
$(document).ready(function() {
      $(".table-row").click(function() {
          window.document.location = $(this).data("href");
      });
  });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\email_finder_verifier\resources\views/list.blade.php ENDPATH**/ ?>