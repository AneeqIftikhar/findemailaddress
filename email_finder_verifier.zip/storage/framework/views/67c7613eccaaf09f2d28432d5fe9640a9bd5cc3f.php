<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\email_finder_verifier\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>