<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><h3>Batch Find Email</h3></div>

                <div class="card-body">
                	<?php if($errors->any()): ?>
					        <?php echo e(implode('', $errors->all('<div>:message</div>'))); ?>

					<?php endif; ?>
                   <form method="POST" action="<?php echo e(route('batch')); ?>" enctype="multipart/form-data" aria-label="<?php echo e(__('Upload')); ?>">
                    <?php echo csrf_field(); ?>
                    	
	                    <div class="form-group row">
	                        <label for="title" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('Title')); ?></label>
	                        <div class="col-md-6">
	                            <input id="title" type="text" class="form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>" name="title" value="<?php echo e(old('title')); ?>" required autofocus />
	                            <?php if($errors->has('title')): ?>
	                                <span class="invalid-feedback" role="alert">
	                                    <strong><?php echo e($errors->first('title')); ?></strong>
	                                </span>
	                            <?php endif; ?>
	                        </div>
	                    </div>
	                    <div class="form-group row">
                    		<label for="excel_file" class="col-sm-4 col-form-label text-md-right"><?php echo e(__('File')); ?></label>
                    		<div class="col-md-6">
                                <input type="file" class="form-control-file" name="excel_file" id="excel_file" aria-describedby="fileHelp">
                                <small id="fileHelp" class="form-text text-muted">Please upload a valid Excel or CSV file. Size of file should not be more than 5MB.</small>
                                <?php if($errors->has('excel_file')): ?>
								    <div class="error"><?php echo e($errors->first('excel_file')); ?></div>
								<?php endif; ?>
                            </div>
                        </div>
                        <div class="form-group row">
                        	<div class="col-sm-4 col-form-label text-md-right">
                        	</div>
                        	<div class="col-md-6">
                        		<button type="submit" class="btn btn-primary">Submit</button>
                        	</div>
                        	
                        </div>
                            
                    </form>
            	</div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\email_finder_verifier\resources\views/batch_find.blade.php ENDPATH**/ ?>