<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><h3>Find Email</h3></div>

                <div class="card-body">
                        <table class="bulk-table">
							<tbody>
								<tr>
									<td>
										<a href="batch_find">
										<h3>
										Email Finder
										</h3>
										<div class="grey">
											Find the email addresses from a list of names and companies.
										</div>
										</a>
									</td>
								</tr>
								<tr>
									<td>
										<a href="batch_verify">
										<h3>
											Email Verifier
										</h3>
										<div class="grey">
											Verify a list of email addresses.
										</div>
										</a>
									</td>
								</tr>
							</tbody>
						</table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\email_finder_verifier\resources\views/batch.blade.php ENDPATH**/ ?>