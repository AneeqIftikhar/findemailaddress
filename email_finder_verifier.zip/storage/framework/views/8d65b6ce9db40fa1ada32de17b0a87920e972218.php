<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Lists</div>

                <div class="card-body">
                    <div class="row" style="margin-bottom: 4px">
                        <div class="col-md-6">
                            <h3>File Title</h3>
                        </div>
                        <div class="col-md-6" align="right">
                         
      
                              <a href="<?php echo e(URL::route('list')); ?>">
                                <button class="btn btn-primary">
                                  <i class="fas fa-undo fa-lg"></i>
                                </button>
                              </a>
                             
                              <button class="btn btn-primary nav-item dropdown">
                                 <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre style="padding: 0px; color: white">
                                    <span><i class="fas fa-download fa-lg"></i></span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-left">
                                <a class="dropdown-item" href="<?php echo e(URL::route('downloadcsv',['id' => $id,'type'=>'csv','records'=>'all'])); ?>">
                                  Download ALL (CSV)
                                </a>
                                <a class="dropdown-item" href="<?php echo e(URL::route('downloadcsv',['id' => $id,'type'=>'xls','records'=>'all'])); ?>">
                                  Download ALL (XLS)
                                </a>
                                <a class="dropdown-item" href="<?php echo e(URL::route('downloadcsv',['id' => $id,'type'=>'csv','records'=>'valid'])); ?>">
                                  Download Valid (CSV)
                                </a>
                                <a class="dropdown-item" href="<?php echo e(URL::route('downloadcsv',['id' => $id,'type'=>'xls','records'=>'valid'])); ?>">
                                  Download Valid (XLS)
                                </a>
                              </div>
                              </button>
                              
                              <button class="btn btn-primary" value="all" id="show_emails">
                                Show All
                              </button>
                             
                        </div>
                    </div>
                   <table class="table" id="emails_table">
                      <thead class="black white-text">
                        <tr>
                            <th scope="col">Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        <!--  <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr class="table-row">    
                              <td> <?php echo e($email->first_name); ?> <?php echo e($email->last_name); ?> </td>
                              <td> <?php echo e($email->email); ?> </td>
                              <td> <?php echo e($email->status); ?> </td>
                          </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                      </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
  var data = null;
$(document).ready(function() {
   data = <?php echo json_encode($emails->toArray(), JSON_HEX_TAG); ?>;
   populate_emails('less');
   $( "#show_emails" ).click(function() {
      if($( "#show_emails" ).val()=="all")
      {
        populate_emails('all');
        $("#show_emails").html('Show Valid');
        $("#show_emails").prop('value', 'less');
      }
      else
      {
        populate_emails('less');
        $("#show_emails").html('Show All');
        $("#show_emails").prop('value', 'all');
      }
      
    });
    
});
  
function populate_emails(filter)
{
   var tableRef = document.getElementById('emails_table').getElementsByTagName('tbody')[0];
      for(var i = tableRef.rows.length - 1; i >= 0; i--)
      {
        tableRef.deleteRow(i);
      }
      for(var i =0;i<data.length;i++)
      {
        
        if(filter=="less" && data[i]['status']=='valid')
        {
          var newRow   = tableRef.insertRow();


          newCell  = newRow.insertCell(0);
          newText  = document.createTextNode(data[i]['first_name']+" "+data[i]['last_name']);
          newCell.appendChild(newText);

          newCell  = newRow.insertCell(1);
          newText  = document.createTextNode(data[i]['email']);
          newCell.appendChild(newText);

          newCell  = newRow.insertCell(2);
          newText  = document.createTextNode(data[i]['status']);
          newCell.appendChild(newText);
        }
        else if(filter=="all")
        {
          var newRow   = tableRef.insertRow();


          newCell  = newRow.insertCell(0);
          newText  = document.createTextNode(data[i]['first_name']+" "+data[i]['last_name']);
          newCell.appendChild(newText);

          newCell  = newRow.insertCell(1);
          newText  = document.createTextNode(data[i]['email']);
          newCell.appendChild(newText);

          newCell  = newRow.insertCell(2);
          newText  = document.createTextNode(data[i]['status']);
          newCell.appendChild(newText);
        }
        

       
      }
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\email_finder_verifier\resources\views/emails.blade.php ENDPATH**/ ?>